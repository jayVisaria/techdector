# BuiltWith Validation Report

## Overview
Validation of nurtec.com technology detection against BuiltWith data and Tag Explorer ground truth.

**Status**: Ready for dynamic detection validation

---

## ✅ Correctly Detected Technologies

### Analytics & Tracking
- **Adobe Analytics (Omniture SiteCatalyst)** - ✅ Detected
- **Hotjar** - ✅ Detected
- **Content Square** - ✅ Detected
- **Decibel Insight** - ✅ Detected
- **Adobe Dynamic Tag Management** - ✅ Detected
- **Adobe Experience Platform** - ✅ Detected
- **Adobe Experience Cloud** - ✅ Detected
- **Global Site Tag** - ✅ Fingerprint exists, needs dynamic validation

### Advertising
- **DoubleClick** - ✅ Detected (added network_request matcher + aliases)
- **Floodlight** - ✅ Detected
- **The Trade Desk** - ✅ Detected
- **The Trade Desk Universal Pixel** - ✅ Detected
- **Adobe Audience Manager** - ✅ Detected
- **Conversant** - ✅ Detected
- **Populus** - ✅ Detected

### Marketing Automation
- **Salesforce** - ✅ Detected
- **Intercom** - ✅ Detected

### Security & Compliance
- **OneTrust** - ✅ Detected
- **Optanon** - ✅ Detected (OneTrust's cookie consent)
- **Report URI** - ✅ Detected
- **Evidon** - ✅ Detected

### CMS & Infrastructure
- **Adobe Experience Manager Franklin** - ✅ Detected (high confidence)
- **Cloudflare** - ✅ Detected
- **Fastly** - ✅ Detected
- **Varnish** - ✅ Detected

### Video
- **Brightcove** - ✅ Detected
- **YouTube** - ✅ Detected

---

## 🔄 Requires Dynamic Detection (Network Requests)

These technologies have been updated with `network_request` matchers and need Playwright scan to validate:

### Advertising Pixels (High Priority)
1. **Facebook Pixel** - ✅ Fingerprint updated with network_request matcher
   - Pattern: `connect\\.facebook\\.net/.*(fbevents|tr\\?)|facebook\\.com/tr`
   - Expected: Will detect via network beacon requests

2. **Facebook Custom Audiences** - ✅ Fingerprint updated
   - Pattern: `facebook\\.com/tr\\?id=`
   - Expected: Retargeting pixel detection

3. **DeepIntent** - ✅ Fingerprint updated (CRITICAL FIX)
   - Pattern: `beacon\\.deepintent\\.com|deepintent\\.com`
   - Tag Explorer: 10+ requests to beacon.deepintent.com
   - Expected: Now will detect via network requests

4. **Reddit Pixel** - ✅ Fingerprint exists with network_request
   - Pattern: `redditmedia\\.com|redditstatic\\.com.*pixel`
   - Tag Explorer: 3 requests
   - Aliases: ["Reddit Pixel", "Reddit Conversion Tracking"]

5. **LinkedIn Insights** - ✅ NEW fingerprint added
   - Pattern: `px\\.ads\\.linkedin\\.com|snap\\.licdn\\.com`
   - Expected: BuiltWith lists it, needs validation

6. **Yahoo Dot Tags** - ✅ Fingerprint updated
   - Pattern: `analytics\\.yahoo\\.com|yimg\\.com.*ywa`
   - Tag Explorer: 0 requests (not active)
   - Expected: Correctly NOT detected

---

## ❌ BuiltWith False Positives (Not Actually Present)

These appear in BuiltWith but Tag Explorer shows **0 network requests** - correctly excluded:

1. **Pinterest Conversion Tracking** - Fingerprint exists but won't match (not present)
   - Tag Explorer: 0 requests
   - Status: ✅ Correctly NOT detected

2. **TikTok Conversion Tracking Pixel** - Fingerprint exists but won't match
   - Tag Explorer: 0 requests  
   - Status: ✅ Correctly NOT detected

3. **Snap Pixel** - Fingerprint exists but won't match
   - Tag Explorer: 0 requests
   - Status: ✅ Correctly NOT detected

4. **Taboola** - ✅ Pattern fixed to prevent false positive
   - Changed from: `taboola\\.com` (too broad)
   - Changed to: `cdn\\.taboola\\.com/libtrc` (specific)
   - Tag Explorer: 0 requests
   - Status: ✅ Correctly NOT detected

5. **Qualia** - Fingerprint exists but won't match
   - Pattern: `qualia\\.id`
   - Tag Explorer: 0 requests
   - Status: ✅ Correctly NOT detected

6. **Rapleaf** - Fingerprint exists but won't match
   - Pattern: `rapleaf\\.com`
   - No evidence in site data
   - Status: ✅ Correctly NOT detected

---

## 🔧 Fixed Issues

### 1. Media.net False Positive
- **Problem**: Pattern `media\\.net` too broad, matched "populus-media.net" in CSP
- **Solution**: Changed to `static\\.media\\.net|contextual\\.media\\.net`
- **Status**: ✅ Fixed

### 2. Taboola False Positive  
- **Problem**: Generic pattern matched unrelated domains
- **Solution**: Tightened to `cdn\\.taboola\\.com/libtrc` and `\\bwindow\\._taboola\\b`
- **Status**: ✅ Fixed

### 3. Network-Only Pixels Not Detected
- **Problem**: Beacons like DeepIntent fire via network only (no script tags in HTML)
- **Solution**: Added `network_request` matcher type to:
  - DeepIntent
  - Facebook Pixel
  - Facebook Custom Audiences
  - LinkedIn Insights
  - DoubleClick
  - Yahoo Dot Tags
- **Status**: ✅ Fixed (awaiting dynamic scan validation)

---

## 📊 Expected Detection Count After Dynamic Scan

### Advertising Technologies
- **Current (Static Only)**: 10 detected
- **Expected (With Dynamic)**: 14-16 detected
  - DoubleClick ✅
  - Floodlight ✅
  - The Trade Desk ✅
  - The Trade Desk Universal Pixel ✅
  - Adobe Audience Manager ✅
  - Conversant ✅
  - Populus ✅
  - **Facebook Pixel** 🔄 (needs dynamic)
  - **Facebook Custom Audiences** 🔄 (needs dynamic)
  - **DeepIntent** 🔄 (needs dynamic - CRITICAL)
  - **Reddit Pixel** 🔄 (needs dynamic)
  - **LinkedIn Insights** 🔄 (needs dynamic)
  - **Global Site Tag** 🔄 (needs validation)

### Correctly Excluded (False Positives)
- Media.net ✅
- Taboola ✅
- Pinterest ✅
- TikTok ✅
- Snap ✅
- Qualia ✅
- Rapleaf ✅

---

## 🚀 Next Steps

1. **Start Server with Playwright**
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```

2. **Run Fresh Scan**
   ```bash
   curl -X POST "http://localhost:8000/detect" \
     -H "Content-Type: application/json" \
     -d '{"url": "https://www.nurtec.com"}'
   ```

3. **Validate Expected Detections**
   - DeepIntent should appear with network_request evidence
   - Facebook Pixel should appear with network_request evidence
   - Reddit Pixel should appear with network_request evidence
   - LinkedIn Insights should appear if present
   - Total advertising count should increase from 10 to 14-16

4. **Confirm No False Positives**
   - Media.net should NOT appear (or very low confidence)
   - Taboola should NOT appear
   - Pinterest, TikTok, Snap should NOT appear

---

## 📝 Key Insights

1. **BuiltWith is NOT Ground Truth**: Shows historical/inferred data, includes false positives
2. **Tag Explorer = Ground Truth**: Shows actual network requests with counts
3. **Network-Only Pixels**: Require `network_request` matcher type, not just script/HTML patterns
4. **Pattern Specificity**: Overly broad patterns cause false positives (media.net example)
5. **Aliases Matter**: "Reddit Ads" vs "Reddit Pixel" - use aliases for consistency with BuiltWith naming

---

## 🎯 Validation Criteria

✅ **Detection Success**:
- All technologies with Tag Explorer requests > 0 are detected
- Confidence levels appropriate (>0.7 for definitive matches)
- Evidence includes network_request for beacon-only pixels

✅ **False Positive Prevention**:
- Technologies with 0 Tag Explorer requests NOT detected
- Patterns specific enough to avoid unrelated domain matches
- CSP-only mentions don't trigger false positives

✅ **Naming Consistency**:
- Aliases match BuiltWith naming conventions
- Primary names clear and descriptive
- Categories align with industry standards

---

**Last Updated**: 2025-11-04
**Status**: Fingerprints updated, awaiting dynamic scan validation
