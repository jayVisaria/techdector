# app/dynamic.py
import asyncio
import re
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

class DynamicDetector:
    def __init__(self, headless: bool = True, timeout: int = 60000):  # Increased to 60 seconds
        self.headless = headless
        self.timeout = timeout

    async def _dismiss_popups(self, page):
        """
        Dismiss common cookie consent popups (OneTrust, CookieBot, etc.)
        """
        popup_selectors = [
            # OneTrust
            "#onetrust-accept-btn-handler",
            ".onetrust-close-btn-handler",
            "#accept-recommended-btn-handler",
            "button[aria-label*='Accept']",
            "button[aria-label*='Accept Cookies']",
            
            # CookieBot
            "#CybotCookiebotDialogBodyButtonAccept",
            ".CybotCookiebotDialogBodyButton",
            
            # Dialog/Modal Close buttons
            "button.dialog-close",
            "button[aria-label='Close']",
            "button[daa-ll*='modalClose']",
            
            # Generic selectors
            "button:has-text('Accept')",
            "button:has-text('Accept All')",
            "button:has-text('I Accept')",
            "button:has-text('Agree')",
            "button:has-text('OK')",
            "a:has-text('Accept')",
            "[id*='cookie'][id*='accept']",
            "[class*='cookie'][class*='accept']",
            "[id*='gdpr'][id*='accept']",
        ]
        
        for selector in popup_selectors:
            try:
                # Wait briefly for popup to appear, then click if found
                await page.wait_for_selector(selector, timeout=2000, state="visible")
                await page.click(selector, timeout=2000)
                print(f"✓ Dismissed popup using selector: {selector}")
                await asyncio.sleep(0.5)  # Wait for popup to close
                break  # Stop after first successful dismissal
            except PlaywrightTimeoutError:
                continue  # Try next selector
            except Exception as e:
                continue  # Try next selector

    async def analyze(self, url, matchers):
        """
        matchers: list of fingerprint dicts (only those that include global_js or dynamic patterns)
        returns list of detections
        """
        results = []
        browser = None
        network_requests = []
        try:
            async with async_playwright() as pw:
                print(f"🚀 Launching Chromium browser (headless={self.headless})...")
                try:
                    browser = await pw.chromium.launch(
                        headless=self.headless,
                        args=[
                            '--no-sandbox',
                            '--disable-setuid-sandbox',
                            '--disable-gpu',
                            '--disable-dev-shm-usage',  # Important for backend/CI environments
                            '--disable-extensions',
                            '--disable-plugins'
                        ]
                    )
                except Exception as launch_error:
                    print(f"❌ Browser launch failed: {launch_error}")
                    print("💡 Try running: playwright install && playwright install-deps")
                    raise
                print(f"✓ Browser launched successfully")
                context = await browser.new_context(
                    viewport={'width': 1920, 'height': 1080},
                    user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                )
                page = await context.new_page()
                page.on("request", lambda request: network_requests.append(request.url))
                print(f"✓ New page created, navigating to {url}...")
                
                # Navigate to the page
                try:
                    await page.goto(url, wait_until="domcontentloaded", timeout=self.timeout)
                except PlaywrightTimeoutError:
                    print(f"Warning: Page load timeout for {url}, continuing anyway...")
                
                # Wait for network to settle
                try:
                    await page.wait_for_load_state("networkidle", timeout=5000)
                except PlaywrightTimeoutError:
                    pass  # Continue even if network doesn't idle
                
                # Dismiss cookie popups (OneTrust, etc.)
                await self._dismiss_popups(page)
                
                # Allow additional time for advertising pixels to fire after consent
                await asyncio.sleep(1)
                
                # get window keys (limited)
                try:
                    globals_list = await page.evaluate("() => Object.keys(window).slice(0,500)")
                    globals_text = " ".join(globals_list)
                except Exception as e:
                    print(f"Error getting window globals: {e}")
                    globals_text = ""
                
                # get scripts loaded after runtime
                try:
                    scripts = await page.eval_on_selector_all("script[src]", "els => els.map(e => e.src)")
                    scripts_text = " ".join(scripts)
                except Exception as e:
                    print(f"Error getting scripts: {e}")
                    scripts_text = ""
                
                # Capture cookies after interactions (OneTrust, etc.)
                try:
                    cookies_list = await context.cookies()
                    cookie_text = " ".join(
                        f"{cookie.get('name','')}={cookie.get('value','')}" for cookie in cookies_list
                    )
                except Exception as e:
                    print(f"Error getting cookies: {e}")
                    cookie_text = ""

                network_text = " ".join(network_requests)

                # Get page HTML for additional analysis
                try:
                    html_content = await page.content()
                except Exception as e:
                    print(f"Error getting page content: {e}")
                    html_content = ""
                
                # match
                for fp in matchers:
                    name = fp['name']
                    category = fp.get('category', 'Other')
                    matches = []
                    score = 0.0
                    weight = fp.get('weight', 1.0)

                    def add_match(label, increment):
                        nonlocal score
                        if label not in matches:
                            matches.append(label)
                            score += increment
                    for m in fp.get('matchers',[]):
                        typ = m['type']; pat = m['pattern']
                        if typ == "global_js_regex":
                            try:
                                if re.search(pat, globals_text, re.I):
                                    add_match(f"global_js:{pat}", 1.2)
                            except re.error:
                                continue
                        if typ == "script_src_regex":
                            try:
                                if re.search(pat, scripts_text, re.I):
                                    add_match(f"script_src:{pat}", 0.9)
                                elif network_text and re.search(pat, network_text, re.I):
                                    add_match(f"network_request:{pat}", 0.75)
                            except re.error:
                                continue
                        if typ == "network_request":
                            try:
                                if network_text and re.search(pat, network_text, re.I):
                                    add_match(f"network_request:{pat}", 0.8)
                            except re.error:
                                continue
                        if typ == "html_regex":
                            try:
                                if re.search(pat, html_content, re.I):
                                    add_match(f"html:{pat}", 1.0)
                            except re.error:
                                continue
                        if typ == "link_regex":
                            try:
                                if re.search(pat, html_content, re.I):
                                    add_match(f"link:{pat}", 0.5)
                            except re.error:
                                continue
                        if typ == "meta_regex":
                            try:
                                if re.search(pat, html_content, re.I):
                                    add_match(f"meta:{pat}", 0.75)
                            except re.error:
                                continue
                        if typ == "cookie_regex" and cookie_text:
                            try:
                                if re.search(pat, cookie_text, re.I):
                                    add_match(f"cookie:{pat}", 0.7)
                            except re.error:
                                continue
                    if matches:
                        confidence = min(0.99, 1 - (0.5 ** (score * weight)))
                        results.append({"name": name, "category": category, "confidence": round(confidence,3), "evidence": matches})
                
                await browser.close()
        except Exception as e:
            print(f"Error in dynamic analysis for {url}: {e}")
            if browser:
                try:
                    await browser.close()
                except:
                    pass
            # Return empty results on error instead of crashing
            return []
        
        return results
