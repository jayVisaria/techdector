# app/storage.py
import json
from pathlib import Path
from elasticsearch import Elasticsearch
import os
from datetime import datetime

BASE = Path(__file__).resolve().parent.parent
SNAP_DIR = BASE / "snapshots"
SNAP_DIR.mkdir(exist_ok=True)

class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)

class Storage:
    def __init__(self, es_url=None):
        self.es = None
        if es_url:
            try:
                self.es = Elasticsearch(es_url)
            except Exception:
                self.es = None

    def save_snapshot(self, domain, payload):
        fname = SNAP_DIR / f"{domain.replace('/', '_')}-{payload.get('timestamp','')}.json"
        with open(fname, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False, cls=DateTimeEncoder)
        return str(fname)

    def index_es(self, index_name, doc):
        if not self.es:
            return False
        try:
            self.es.index(index=index_name, document=doc)
            return True
        except Exception as e:
            print("ES index error:", e)
            return False
