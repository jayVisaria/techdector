#!/usr/bin/env python3

import json
import re

def load_fingerprints():
    """Load the fingerprints.json file"""
    with open('fingerprints.json', 'r') as f:
        data = json.load(f)
        # Convert list to dict for easier access
        fingerprints_dict = {}
        for i, tech in enumerate(data.get('tech', [])):
            fingerprints_dict[i] = tech
        return fingerprints_dict

def analyze_tag_explorer_vs_detected():
    """Compare Tag Explorer results with our detected technologies"""
    
    # Tag Explorer detected technologies (from the provided data)
    tag_explorer_detected = {
        "Adobe Dynamic Tag Management": {
            "urls": ["assets.adobedtm.com"],
            "detected_by_us": True
        },
        "Adobe Launch": {
            "urls": ["assets.adobedtm.com/22baa8e94be8/24625b4edc68/launch-5c9c02c09e2e.min.js"],
            "detected_by_us": True  # We detect "Adobe Experience Platform Tags (Adobe Launch)"
        },
        "AdsWizz": {
            "urls": ["synchroscript.deliveryengine.adswizz.com"],
            "detected_by_us": False
        },
        "Beachfront": {
            "urls": ["sync.bfmio.com"],
            "detected_by_us": False
        },
        "Brightcove": {
            "urls": ["players.brightcove.net", "edge.api.brightcove.com", "metrics.brightcove.com"],
            "detected_by_us": True
        },
        "Cloudflare Web Analytics": {
            "urls": ["static.cloudflareinsights.com/beacon.min.js"],
            "detected_by_us": True
        },
        "Conversant": {
            "urls": ["login-ds.dotomi.com", "dclk-match.dotomi.com", "yahoo-match.dotomi.com"],
            "detected_by_us": True
        },
        "DeepIntent": {
            "urls": ["beacon.deepintent.com"],
            "detected_by_us": False
        },
        "Facebook Pixel": {
            "urls": ["connect.facebook.net/en_US/fbevents.js", "www.facebook.com/tr/"],
            "detected_by_us": True
        },
        "Facebook Social Plugins": {
            "urls": ["connect.facebook.net"],
            "detected_by_us": True  # We detect "Facebook Comments"
        },
        "Floodlight": {
            "urls": ["googletagmanager.com/gtag/js?id=DC-", "ad.doubleclick.net/activity"],
            "detected_by_us": True
        },
        "Google Authorized Buyers - Cookie Match": {
            "urls": ["cm.g.doubleclick.net"],
            "detected_by_us": False
        },
        "Index Exchange": {
            "urls": ["dsum-sec.casalemedia.com"],
            "detected_by_us": False
        },
        "Integral Ad Science": {
            "urls": ["pixel.adsafeprotected.com"],
            "detected_by_us": False
        },
        "LiveRamp": {
            "urls": ["di.rlcdn.com"],
            "detected_by_us": True
        },
        "LoopMe": {
            "urls": ["csync.loopme.me"],
            "detected_by_us": False
        },
        "Mediaplex": {
            "urls": ["exchange-match.mediaplex.com"],
            "detected_by_us": False
        },
        "OneTrust": {
            "urls": ["cdn.cookielaw.org"],
            "detected_by_us": True
        },
        "Reddit Pixel": {
            "urls": ["www.redditstatic.com/ads/pixel.js", "alb.reddit.com/rp.gif"],
            "detected_by_us": True  # We detect "Reddit Ads"
        },
        "Verizon Media": {
            "urls": ["cms.analytics.yahoo.com", "ups.analytics.yahoo.com"],
            "detected_by_us": False
        },
        "Yahoo Dot Tags": {
            "urls": ["analytics.yahoo.com"],
            "detected_by_us": False
        }
    }
    
    # Load our fingerprints
    fingerprints = load_fingerprints()
    
    print("=== TAG EXPLORER VS OUR DETECTION COMPARISON ===\n")
    
    missing_technologies = []
    
    for tech_name, info in tag_explorer_detected.items():
        if not info["detected_by_us"]:
            missing_technologies.append((tech_name, info["urls"]))
            print(f"❌ MISSING: {tech_name}")
            print(f"   URLs: {', '.join(info['urls'])}")
            
            # Check if we have this technology in our fingerprints
            matching_techs = []
            for tech_id, tech_data in fingerprints.items():
                if tech_name.lower() in tech_data.get('name', '').lower():
                    matching_techs.append((tech_id, tech_data['name']))
            
            if matching_techs:
                print(f"   📋 Found in fingerprints: {matching_techs}")
                # Analyze the matchers
                for tech_id, _ in matching_techs:
                    tech_data = fingerprints[tech_id]
                    print(f"   🔍 Matchers for {tech_data['name']}:")
                    matchers = tech_data.get('matchers', [])
                    for matcher in matchers:
                        matcher_type = matcher.get('type', 'unknown')
                        pattern = matcher.get('pattern', 'no pattern')
                        print(f"      - {matcher_type}: {pattern}")
            else:
                print(f"   ❓ Not found in fingerprints database")
            print()
        else:
            print(f"✅ DETECTED: {tech_name}")
    
    print(f"\n=== SUMMARY ===")
    print(f"Total Tag Explorer technologies: {len(tag_explorer_detected)}")
    detected_count = sum(1 for info in tag_explorer_detected.values() if info["detected_by_us"])
    print(f"Detected by us: {detected_count}")
    print(f"Missing: {len(missing_technologies)}")
    print(f"Detection rate: {detected_count/len(tag_explorer_detected)*100:.1f}%")
    
    return missing_technologies

def check_missing_tech_matchers():
    """Check specific matcher issues for missing technologies"""
    fingerprints = load_fingerprints()
    
    # Technologies we know are missing
    missing_tech_patterns = {
        "AdsWizz": ["adswizz", "deliveryengine"],
        "Beachfront": ["bfmio", "beachfront"],
        "DeepIntent": ["deepintent"],
        "Google Authorized Buyers": ["doubleclick.net/pixel", "google_cm"],
        "Index Exchange": ["casalemedia"],
        "Integral Ad Science": ["adsafeprotected"],
        "LoopMe": ["loopme"],
        "Mediaplex": ["mediaplex"],
        "Verizon Media": ["analytics.yahoo.com", "verizon"],
        "Yahoo Dot Tags": ["yahoo", "dot tags"]
    }
    
    print("\n=== MISSING TECHNOLOGY MATCHER ANALYSIS ===\n")
    
    for missing_tech, search_patterns in missing_tech_patterns.items():
        print(f"🔍 Searching for {missing_tech}...")
        found_matches = []
        
        for tech_id, tech_data in fingerprints.items():
            tech_name = tech_data.get('name', '').lower()
            
            # Check if any search pattern matches
            for pattern in search_patterns:
                if pattern.lower() in tech_name:
                    found_matches.append((tech_id, tech_data['name'], tech_data.get('matchers', [])))
                    break
        
        if found_matches:
            for tech_id, name, matchers in found_matches:
                print(f"  ✅ Found: {name} (ID: {tech_id})")
                matcher_types = [m.get('type', 'unknown') for m in matchers]
                print(f"     Matchers: {matcher_types}")
                
                # Check for problematic matcher types
                problematic_matchers = []
                for matcher in matchers:
                    matcher_type = matcher.get('type', 'unknown')
                    if matcher_type not in ['script_src_regex', 'html_regex', 'header_regex', 'meta_regex', 'cookie_regex', 'link_regex', 'global_js_regex']:
                        problematic_matchers.append(matcher_type)
                
                if problematic_matchers:
                    print(f"     ⚠️  Unsupported matcher types: {problematic_matchers}")
                else:
                    print(f"     ✅ All matcher types supported")
        else:
            print(f"  ❌ Not found in fingerprints database")
        print()

if __name__ == "__main__":
    missing_techs = analyze_tag_explorer_vs_detected()
    check_missing_tech_matchers()