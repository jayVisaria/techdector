#!/usr/bin/env python3

import json
import re
from typing import List, Dict, Any

def test_matchers():
    """Test the updated matchers against the specific URLs from tag explorer."""
    
    # Load the updated fingerprints
    with open('fingerprints.json', 'r') as f:
        data = json.load(f)
    
    # Test URLs from tag explorer
    test_urls = [
        # Adobe Dynamic Tag Management
        "https://assets.adobedtm.com/22baa8e94be8/24625b4edc68/dc6f2f12d3e0/RCfbab19095b0f4e439dd7ea847e552118-source.min.js",
        "https://assets.adobedtm.com/22baa8e94be8/24625b4edc68/dc6f2f12d3e0/RC9e96d30018ac4549b7a1ef6488bbb048-source.min.js",
        
        # Adobe Launch  
        "https://assets.adobedtm.com/22baa8e94be8/24625b4edc68/launch-5c9c02c09e2e.min.js",
        
        # Brightcove
        "https://players.brightcove.net/1852113022001/g2OtgoAoBs_default/index.min.js",
        "https://metrics.brightcove.com/v2/tracker?domain=videocloud&platform=video-js",
        
        # Cloudflare Web Analytics
        "https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015",
        
        # Conversant
        "https://login-ds.dotomi.com/profile/visit/final/js?dtm_token_dc=AQAKrZOJd9WxFAEdCYRdAQBCswABAQCbSZLNLAEBAJtJks0s",
        
        # DeepIntent
        "https://beacon.deepintent.com/conversion?id=dfdfd2ac-321a-418a-a45b-d4752154d2f1",
        
        # Facebook Pixel
        "https://connect.facebook.net/en_US/fbevents.js",
        "https://connect.facebook.net/signals/config/1369887373935952",
        "https://www.facebook.com/tr/?id=1369887373935952&ev=PageView",
        "https://www.facebook.com/privacy_sandbox/pixel/register/trigger/?id=1369887373935952",
        
        # Missing technologies
        "https://cm.g.doubleclick.net/pixel?google_nid=epsilon-ddp",  # Google Authorized Buyers
        "https://sync.crwdcntrl.net/qmap?c=18048&tp=EPSN",  # Lotame
        "https://pixel.rubiconproject.com/tap.php?v=5364|1|90&nid=2046",  # Magnite
        "https://us-u.openx.net/w/1.0/sd?id=537072954",  # OpenX
        "https://eb2.3lift.com/xuid?mid=6732&dongle=38F",  # TripleLift
        "https://ib.adnxs.com/setuid?entity=34&code=AQAKzmJ",  # Xandr
        
        # LiveRamp
        "https://di.rlcdn.com/712988.html?pdata=sessionid",
        
        # Reddit Ads
        "https://www.redditstatic.com/ads/pixel.js",
        "https://alb.reddit.com/rp.gif?ts=1762238928761",
        
        # OneTrust
        "https://cdn.cookielaw.org/scripttemplates/otSDKStub.js",
        "https://cdn.cookielaw.org/consent/0198a2fe-15ea-7748-8605-9dc892771244/0198a2fe-15ea-7748-8605-9dc892771244.json",
        
        # PubMatic
        "https://simage2.pubmatic.com/AdServer/Pug?vcode=bz0yJnR5cGU9MSZjb2RlPTQ2MSZ0bD0xNTc2ODAw"
    ]
    
    technologies_to_test = [
        "Adobe Dynamic Tag Management",
        "Adobe Experience Platform Tags (Adobe Launch)", 
        "Brightcove",
        "Cloudflare Web Analytics",
        "Conversant",
        "DeepIntent",
        "Facebook Pixel",
        "Google Authorized Buyers",
        "Lotame", 
        "Magnite",
        "OpenX",
        "TripleLift",
        "Xandr",
        "LiveRamp",
        "Reddit Ads",
        "OneTrust",
        "PubMatic"
    ]
    
    results = {}
    
    for tech_name in technologies_to_test:
        tech = None
        for t in data['tech']:
            if t['name'] == tech_name:
                tech = t
                break
        
        if not tech:
            results[tech_name] = {"status": "NOT_FOUND_IN_FINGERPRINTS", "matches": []}
            continue
            
        matches = []
        for url in test_urls:
            for matcher in tech['matchers']:
                if matcher['type'] in ['script_src_regex', 'network_request_regex']:
                    try:
                        pattern = matcher['pattern']
                        if re.search(pattern, url, re.IGNORECASE):
                            matches.append({"url": url, "pattern": pattern, "type": matcher['type']})
                    except re.error as e:
                        print(f"Regex error in {tech_name}: {pattern} - {e}")
        
        results[tech_name] = {
            "status": "FOUND" if matches else "NO_MATCHES",
            "matches": matches,
            "matcher_count": len(tech['matchers'])
        }
    
    return results

def print_results(results: Dict[str, Any]):
    """Print test results in a readable format."""
    
    print("=" * 80)
    print("MATCHER VALIDATION TEST RESULTS")
    print("=" * 80)
    
    detected = []
    not_detected = []
    missing = []
    
    for tech_name, result in results.items():
        if result['status'] == 'NOT_FOUND_IN_FINGERPRINTS':
            missing.append(tech_name)
        elif result['status'] == 'FOUND':
            detected.append((tech_name, len(result['matches'])))
        else:
            not_detected.append(tech_name)
    
    print(f"\n✅ DETECTED ({len(detected)} technologies):")
    for tech, match_count in detected:
        print(f"   • {tech} - {match_count} URL matches")
    
    print(f"\n❌ NOT DETECTED ({len(not_detected)} technologies):")
    for tech in not_detected:
        print(f"   • {tech}")
    
    print(f"\n⚠️  MISSING FROM FINGERPRINTS ({len(missing)} technologies):")
    for tech in missing:
        print(f"   • {tech}")
    
    print(f"\n📊 SUMMARY:")
    print(f"   Total tested: {len(results)}")
    print(f"   Successfully detected: {len(detected)} ({len(detected)/len(results)*100:.1f}%)")
    print(f"   Need matcher fixes: {len(not_detected)} ({len(not_detected)/len(results)*100:.1f}%)")
    print(f"   Missing entirely: {len(missing)} ({len(missing)/len(results)*100:.1f}%)")
    
    # Detailed results
    print(f"\n🔍 DETAILED RESULTS:")
    for tech_name, result in results.items():
        if result['matches']:
            print(f"\n{tech_name}:")
            for match in result['matches'][:3]:  # Show first 3 matches
                print(f"   ✓ {match['type']}: {match['pattern']}")
                print(f"     Matched: {match['url'][:80]}...")

if __name__ == "__main__":
    results = test_matchers()
    print_results(results)