#!/usr/bin/env python3

import json
import re

def test_specific_matchers():
    """Test specific matchers for technologies we have but aren't detecting"""
    
    # Load fingerprints
    with open('fingerprints.json', 'r') as f:
        data = json.load(f)
        fingerprints = {i: tech for i, tech in enumerate(data.get('tech', []))}
    
    # Test URLs from Tag Explorer
    test_cases = [
        {
            "tech_name": "DeepIntent",
            "tech_id": 247,
            "test_urls": [
                "https://beacon.deepintent.com/conversion?id=7cf51092-fc0b-42db-b5e3-9ceac2dbdc15"
            ]
        },
        {
            "tech_name": "Integral Ad Science", 
            "tech_id": 243,
            "test_urls": [
                "https://pixel.adsafeprotected.com/?anId=930822&advId=82866"
            ]
        },
        {
            "tech_name": "Yahoo Dot Tags",
            "tech_id": 254,
            "test_urls": [
                "https://cms.analytics.yahoo.com/cms?partner_id=PCLOUD",
                "https://ups.analytics.yahoo.com/ups/58678/cms?partner_id=PCLOUD"
            ]
        }
    ]
    
    print("=== MATCHER TESTING FOR UNDETECTED TECHNOLOGIES ===\n")
    
    for test_case in test_cases:
        tech_name = test_case["tech_name"]
        tech_id = test_case["tech_id"]
        test_urls = test_case["test_urls"]
        
        print(f"🔍 Testing {tech_name} (ID: {tech_id})")
        
        tech_data = fingerprints.get(tech_id)
        if not tech_data:
            print(f"  ❌ Technology not found in fingerprints")
            continue
            
        matchers = tech_data.get('matchers', [])
        print(f"  📋 Matchers:")
        
        for matcher in matchers:
            matcher_type = matcher.get('type', 'unknown')
            pattern = matcher.get('pattern', 'no pattern')
            print(f"    - {matcher_type}: {pattern}")
        
        print(f"  🧪 Testing against URLs:")
        
        for url in test_urls:
            print(f"    URL: {url}")
            
            # Test each matcher
            for matcher in matchers:
                matcher_type = matcher.get('type', 'unknown')
                pattern = matcher.get('pattern', 'no pattern')
                
                try:
                    if matcher_type == 'script_src_regex':
                        # For script_src_regex, we need to check if this URL would be in a script src
                        match = re.search(pattern, url, re.IGNORECASE)
                        if match:
                            print(f"      ✅ {matcher_type} MATCHES: {pattern}")
                        else:
                            print(f"      ❌ {matcher_type} no match: {pattern}")
                    
                    elif matcher_type == 'html_regex':
                        # For html_regex, check if the URL pattern matches
                        match = re.search(pattern, url, re.IGNORECASE)
                        if match:
                            print(f"      ✅ {matcher_type} MATCHES: {pattern}")
                        else:
                            print(f"      ❌ {matcher_type} no match: {pattern}")
                    
                    elif matcher_type == 'link_regex':
                        # For link_regex, check if the URL pattern matches
                        match = re.search(pattern, url, re.IGNORECASE)
                        if match:
                            print(f"      ✅ {matcher_type} MATCHES: {pattern}")
                        else:
                            print(f"      ❌ {matcher_type} no match: {pattern}")
                    
                    else:
                        print(f"      ⚠️  Cannot test {matcher_type} against URL")
                        
                except Exception as e:
                    print(f"      ❌ Error testing {matcher_type}: {e}")
        
        print()

def analyze_detection_gaps():
    """Analyze why certain technologies aren't being detected"""
    
    print("=== DETECTION GAP ANALYSIS ===\n")
    
    gaps = [
        {
            "name": "DeepIntent",
            "tag_explorer_evidence": "beacon.deepintent.com/conversion requests",
            "our_matchers": "script_src_regex and html_regex for deepintent.com domains",
            "issue": "Network requests to beacon.deepintent.com may not appear in HTML source - only visible in network traffic"
        },
        {
            "name": "Integral Ad Science", 
            "tag_explorer_evidence": "pixel.adsafeprotected.com requests",
            "our_matchers": "script_src_regex and link_regex for adsafeprotected.com",
            "issue": "Pixel requests may be dynamically generated, not in HTML source"
        },
        {
            "name": "Yahoo Dot Tags",
            "tag_explorer_evidence": "cms.analytics.yahoo.com and ups.analytics.yahoo.com requests", 
            "our_matchers": "script_src_regex for sp.analytics.yahoo.com and s.yimg.com",
            "issue": "Pattern mismatch - we look for sp.analytics.yahoo.com but Tag Explorer shows cms.analytics.yahoo.com"
        }
    ]
    
    for gap in gaps:
        print(f"❌ {gap['name']}")
        print(f"  Tag Explorer Evidence: {gap['tag_explorer_evidence']}")
        print(f"  Our Matchers: {gap['our_matchers']}")
        print(f"  Issue: {gap['issue']}")
        print()
    
    print("🔧 RECOMMENDATIONS:")
    print("1. DeepIntent: Add html_regex pattern for 'beacon.deepintent.com' requests")
    print("2. Integral Ad Science: Add html_regex pattern for 'pixel.adsafeprotected.com' requests") 
    print("3. Yahoo Dot Tags: Update script_src_regex to include 'cms.analytics.yahoo.com' and 'ups.analytics.yahoo.com'")
    print("4. Missing technologies (AdsWizz, Beachfront, etc.): Add to fingerprints database")

if __name__ == "__main__":
    test_specific_matchers()
    analyze_detection_gaps()