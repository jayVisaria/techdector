#!/usr/bin/env python3

import json
import re

def test_improved_matchers():
    """Test the improved matchers against Tag Explorer evidence"""
    
    # Load fingerprints
    with open('fingerprints.json', 'r') as f:
        data = json.load(f)
        fingerprints = {i: tech for i, tech in enumerate(data.get('tech', []))}
    
    # Tag Explorer test cases
    test_cases = [
        {
            "tech": "Yahoo Dot Tags",
            "urls": [
                "https://cms.analytics.yahoo.com/cms?partner_id=PCLOUD",
                "https://ups.analytics.yahoo.com/ups/58678/cms?partner_id=PCLOUD"
            ]
        },
        {
            "tech": "AdsWizz", 
            "urls": [
                "https://synchroscript.deliveryengine.adswizz.com/syncMe?partnerDomain=dotomi.com"
            ]
        },
        {
            "tech": "Beachfront",
            "urls": [
                "https://sync.bfmio.com/sync?pid=194&uid=AQAKzmJ"
            ]
        },
        {
            "tech": "Index Exchange",
            "urls": [
                "https://dsum-sec.casalemedia.com/rum?cm_dsp_id=65"
            ]
        },
        {
            "tech": "LoopMe",
            "urls": [
                "https://csync.loopme.me/?partner_id=1377&uid=AQAKzmJ"
            ]
        },
        {
            "tech": "Mediaplex",
            "urls": [
                "https://exchange-match.mediaplex.com/sync/px/1?networkId=67750"
            ]
        },
        {
            "tech": "DeepIntent",
            "urls": [
                "https://beacon.deepintent.com/conversion?id=7cf51092-fc0b-42db-b5e3-9ceac2dbdc15"
            ]
        },
        {
            "tech": "Integral Ad Science",
            "urls": [
                "https://pixel.adsafeprotected.com/?anId=930822&advId=82866"
            ]
        }
    ]
    
    print("=== TESTING IMPROVED MATCHERS AGAINST TAG EXPLORER DATA ===\n")
    
    total_tests = 0
    successful_matches = 0
    
    for test_case in test_cases:
        tech_name = test_case["tech"]
        test_urls = test_case["urls"]
        
        print(f"🧪 Testing {tech_name}")
        
        # Find technology in fingerprints
        tech_found = None
        for tech_id, tech_data in fingerprints.items():
            if tech_data.get('name') == tech_name:
                tech_found = (tech_id, tech_data)
                break
        
        if not tech_found:
            print(f"  ❌ Technology not found in fingerprints")
            continue
            
        tech_id, tech_data = tech_found
        matchers = tech_data.get('matchers', [])
        
        print(f"  📋 Available matchers:")
        for matcher in matchers:
            matcher_type = matcher.get('type', 'unknown')
            pattern = matcher.get('pattern', 'no pattern')
            print(f"    - {matcher_type}: {pattern}")
        
        # Test each URL
        for url in test_urls:
            print(f"  🎯 Testing URL: {url}")
            total_tests += 1
            url_matched = False
            
            for matcher in matchers:
                matcher_type = matcher.get('type', 'unknown')
                pattern = matcher.get('pattern', 'no pattern')
                
                try:
                    if matcher_type in ['script_src_regex', 'html_regex', 'link_regex']:
                        if re.search(pattern, url, re.IGNORECASE):
                            print(f"    ✅ MATCH: {matcher_type} - {pattern}")
                            url_matched = True
                        else:
                            print(f"    ❌ No match: {matcher_type} - {pattern}")
                    else:
                        print(f"    ⚠️  Cannot test {matcher_type} against URL")
                except Exception as e:
                    print(f"    ❌ Error testing {matcher_type}: {e}")
            
            if url_matched:
                successful_matches += 1
                
        print()
    
    print("=== TEST RESULTS SUMMARY ===")
    print(f"Total URL tests: {total_tests}")
    print(f"Successful matches: {successful_matches}")
    print(f"Match rate: {successful_matches/total_tests*100:.1f}%" if total_tests > 0 else "No tests performed")
    
    if successful_matches < total_tests:
        print(f"\n⚠️  {total_tests - successful_matches} URLs not matched - may require network request detection")

if __name__ == "__main__":
    test_improved_matchers()