#!/usr/bin/env python3

import json
import re
from typing import List, Dict, Any

def validate_all_matchers():
    """Validate all matchers in fingerprints.json for compatibility and issues."""
    
    # Load fingerprints
    with open('fingerprints.json', 'r') as f:
        data = json.load(f)
    
    # Supported matcher types by the detection system
    SUPPORTED_TYPES = {
        'script_src_regex',
        'html_regex',
        'header_regex',
        'meta_regex',
        'cookie_regex',
        'link_regex',
        'global_js_regex'  # Note: global_js_regex is for dynamic detection only
    }
    
    issues = []
    tech_stats = {
        'total_technologies': 0,
        'total_matchers': 0,
        'unsupported_matcher_types': 0,
        'regex_errors': 0,
        'technologies_with_issues': 0,
        'technologies_with_only_global_js': 0
    }
    
    for tech in data.get('tech', []):
        tech_stats['total_technologies'] += 1
        tech_name = tech.get('name', 'Unknown')
        tech_issues = []
        
        matchers = tech.get('matchers', [])
        tech_stats['total_matchers'] += len(matchers)
        
        has_static_matcher = False
        has_global_js_only = True
        
        for i, matcher in enumerate(matchers):
            matcher_type = matcher.get('type', '')
            pattern = matcher.get('pattern', '')
            
            # Check for unsupported matcher types
            if matcher_type not in SUPPORTED_TYPES:
                tech_issues.append(f"Unsupported matcher type: '{matcher_type}'")
                tech_stats['unsupported_matcher_types'] += 1
            
            # Check if matcher type is supported for static detection
            if matcher_type in ['script_src_regex', 'html_regex', 'header_regex', 'meta_regex', 'cookie_regex', 'link_regex']:
                has_static_matcher = True
                has_global_js_only = False
            
            # Validate regex patterns
            if matcher_type.endswith('_regex'):
                try:
                    re.compile(pattern, re.IGNORECASE)
                except re.error as e:
                    tech_issues.append(f"Invalid regex pattern in {matcher_type}: '{pattern}' - {str(e)}")
                    tech_stats['regex_errors'] += 1
            
            # Check for empty patterns
            if not pattern or pattern.strip() == '':
                tech_issues.append(f"Empty pattern in {matcher_type}")
            
            # Check for overly broad patterns that might cause false positives
            if matcher_type == 'html_regex' and len(pattern) < 4:
                tech_issues.append(f"Very short HTML pattern might cause false positives: '{pattern}'")
        
        # Check if technology only has global_js_regex (won't work with static detection)
        if matchers and all(m.get('type') == 'global_js_regex' for m in matchers):
            tech_issues.append("Only has global_js_regex matchers - won't be detected in static analysis")
            tech_stats['technologies_with_only_global_js'] += 1
        
        # Check if technology has no matchers at all
        if not matchers:
            tech_issues.append("No matchers defined")
        
        if tech_issues:
            issues.append({
                'technology': tech_name,
                'category': tech.get('category', 'Unknown'),
                'issues': tech_issues
            })
            tech_stats['technologies_with_issues'] += 1
    
    return issues, tech_stats

def print_validation_results(issues: List[Dict], stats: Dict):
    """Print validation results in a readable format."""
    
    print("=" * 80)
    print("COMPREHENSIVE MATCHER VALIDATION RESULTS")
    print("=" * 80)
    
    # Print statistics
    print(f"\n📊 OVERALL STATISTICS:")
    print(f"   Total Technologies: {stats['total_technologies']}")
    print(f"   Total Matchers: {stats['total_matchers']}")
    print(f"   Technologies with Issues: {stats['technologies_with_issues']} ({stats['technologies_with_issues']/stats['total_technologies']*100:.1f}%)")
    print(f"   Unsupported Matcher Types: {stats['unsupported_matcher_types']}")
    print(f"   Regex Errors: {stats['regex_errors']}")
    print(f"   Technologies with Only Global JS: {stats['technologies_with_only_global_js']}")
    
    # Print issues by category
    if issues:
        print(f"\n❌ ISSUES FOUND ({len(issues)} technologies):")
        
        # Group issues by type
        unsupported_types = []
        regex_errors = []
        global_js_only = []
        other_issues = []
        
        for issue in issues:
            for problem in issue['issues']:
                if 'Unsupported matcher type' in problem:
                    unsupported_types.append(issue)
                elif 'Invalid regex pattern' in problem:
                    regex_errors.append(issue)
                elif 'Only has global_js_regex' in problem:
                    global_js_only.append(issue)
                else:
                    other_issues.append(issue)
        
        # Print unsupported matcher types
        if unsupported_types:
            print(f"\n🚫 UNSUPPORTED MATCHER TYPES ({len(set(i['technology'] for i in unsupported_types))} technologies):")
            for issue in unsupported_types:
                print(f"   • {issue['technology']} ({issue['category']})")
                for problem in issue['issues']:
                    if 'Unsupported matcher type' in problem:
                        print(f"     - {problem}")
        
        # Print regex errors
        if regex_errors:
            print(f"\n🔍 REGEX PATTERN ERRORS ({len(set(i['technology'] for i in regex_errors))} technologies):")
            for issue in regex_errors:
                print(f"   • {issue['technology']} ({issue['category']})")
                for problem in issue['issues']:
                    if 'Invalid regex pattern' in problem:
                        print(f"     - {problem}")
        
        # Print global JS only issues
        if global_js_only:
            print(f"\n⚠️  STATIC DETECTION INCOMPATIBLE ({len(global_js_only)} technologies):")
            for issue in global_js_only:
                print(f"   • {issue['technology']} ({issue['category']})")
                print(f"     - Won't be detected in static analysis (only has global_js_regex)")
        
        # Print other issues
        if other_issues:
            print(f"\n🔧 OTHER ISSUES ({len(set(i['technology'] for i in other_issues))} technologies):")
            for issue in other_issues:
                print(f"   • {issue['technology']} ({issue['category']})")
                for problem in issue['issues']:
                    if not any(x in problem for x in ['Unsupported matcher type', 'Invalid regex pattern', 'Only has global_js_regex']):
                        print(f"     - {problem}")
    
    else:
        print(f"\n✅ NO ISSUES FOUND!")
        print(f"   All {stats['total_technologies']} technologies have valid, compatible matchers")
    
    print(f"\n🎯 COMPATIBILITY SUMMARY:")
    compatible_techs = stats['total_technologies'] - stats['technologies_with_only_global_js'] - len([i for i in issues if any('Unsupported matcher type' in p for p in i['issues'])])
    print(f"   Static Detection Compatible: {compatible_techs}/{stats['total_technologies']} ({compatible_techs/stats['total_technologies']*100:.1f}%)")
    print(f"   Dynamic Detection Only: {stats['technologies_with_only_global_js']}/{stats['total_technologies']} ({stats['technologies_with_only_global_js']/stats['total_technologies']*100:.1f}%)")

if __name__ == "__main__":
    issues, stats = validate_all_matchers()
    print_validation_results(issues, stats)