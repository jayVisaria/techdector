# Groupify - Quick Start Guide

## Get Started in 3 Steps

### Step 1: Install Dependencies

```bash
# Navigate to the project directory
cd matching_app

# Run the setup script (macOS/Linux)
./setup.sh

# Or manually:
python3 -m venv venv
source venv/bin/activate  # On macOS/Linux
# venv\Scripts\activate   # On Windows
pip install -r requirements.txt
```

### Step 2: Configure Environment

Copy `.env.example` to `.env` and customize:

```bash
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///groupify.db
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
```

### Step 3: Run the Application

```bash
# Activate virtual environment (if not already active)
source venv/bin/activate

# Run the application
python app.py
```

Visit: **http://127.0.0.1:5000**

---

## Quick Demo Walkthrough

### 1. Admin Setup (First Time)

1. Go to http://127.0.0.1:5000/admin/login
2. Login with credentials from `.env` (default: admin/admin123)
3. Create sample questions by running:
   ```bash
   python create_sample_data.py
   ```

### 2. Create a Survey

1. In admin dashboard, click "Create Surveys"
2. Enter:
   - Survey Name: "Team Formation Survey"
   - Number of Surveys: 2
   - Max Users: 10
3. Click "Create Surveys"

### 3. Register Users

1. Open http://127.0.0.1:5000 in incognito/private windows
2. Register 4-6 test users:
   - user1@test.com / password123
   - user2@test.com / password123
   - etc.

### 4. Complete Surveys

For each user:
1. Login
2. Go to Dashboard
3. Click "Take Survey" on available survey
4. Answer all questions
5. Submit

### 5. Form Groups

As admin:
1. Go to admin dashboard
2. Find the survey with participants
3. Click "Complete" button
4. Groups will be automatically formed!

### 6. View Groups

As user:
- Go to "My Groups" to see your assigned group and members

As admin:
- Click "View Groups" on completed survey
- Manually adjust groups if needed (add/remove members)

---

## Key Features to Try

### For Users:
- ✅ Register and create profile
- ✅ Browse available surveys
- ✅ Complete surveys
- ✅ View assigned groups
- ✅ See group members

### For Admins:
- ✅ Create/edit/delete questions
- ✅ Create multiple surveys
- ✅ Monitor participation
- ✅ Trigger automatic group formation
- ✅ Manually adjust groups
- ✅ View statistics

---

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 5000
lsof -ti:5000 | xargs kill -9
```

### Database Issues
```bash
# Delete and recreate database
rm instance/groupify.db
python app.py
```

### Module Not Found
```bash
# Ensure virtual environment is activated
source venv/bin/activate
pip install -r requirements.txt
```

---

## Project Structure

```
matching_app/
├── app.py                    # Main application
├── models.py                 # Database models
├── forms.py                  # Form definitions
├── matching_algorithm.py     # AI matching logic
├── config.py                 # Configuration
├── requirements.txt          # Dependencies
├── create_sample_data.py     # Sample data generator
├── static/
│   └── css/
│       └── style.css        # Styles
└── templates/               # HTML templates
```

---

## Color Scheme Reference

- **Primary**: #42A5F5 (Deep sky blue)
- **Background**: #ECEFF1 (Light grayish-blue)
- **Accent**: #FF7043 (Vivid orange)
- **Font**: PT Sans

---

## Next Steps

1. **Customize Questions**: Create domain-specific questions
2. **Test Matching**: Create users with similar/different answers
3. **Adjust Groups**: Practice manual group adjustments
4. **Export Data**: Add CSV export functionality
5. **Deploy**: Deploy to production server

---

## Support

Check `README.md` for detailed documentation and API reference.
