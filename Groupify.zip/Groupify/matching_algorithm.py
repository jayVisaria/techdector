import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from models import db, UserAnswer, Group, GroupMember, Survey, User
from collections import defaultdict

def calculate_similarity(user1_answers, user2_answers):
    """
    Calculate similarity between two users based on their answers.
    Returns a score between 0 and 1, where 1 is identical answers.
    """
    if len(user1_answers) != len(user2_answers):
        return 0
    
    # Convert answers to binary vectors (0 or 1)
    vec1 = np.array([1 if ans == 1 else 0 for ans in user1_answers])
    vec2 = np.array([1 if ans == 1 else 0 for ans in user2_answers])
    
    # Calculate cosine similarity
    similarity = cosine_similarity([vec1], [vec2])[0][0]
    
    # Also calculate exact match percentage
    matches = sum(1 for a, b in zip(user1_answers, user2_answers) if a == b)
    match_percentage = matches / len(user1_answers)
    
    # Combine both metrics (weighted average)
    return 0.6 * match_percentage + 0.4 * similarity


def get_user_answers(user_id, survey_id):
    """Get all answers for a user in a specific survey, ordered by question_id."""
    answers = UserAnswer.query.filter_by(
        user_id=user_id, 
        survey_id=survey_id
    ).order_by(UserAnswer.question_id).all()
    
    return [answer.answer_choice for answer in answers]


def form_groups_for_survey(survey_id):
    """
    Form groups for a survey based on answer similarity.
    Creates groups of 2 users with the most similar answers.
    """
    survey = Survey.query.get(survey_id)
    if not survey:
        return False
    
    # Get all users who completed the survey
    user_answers = db.session.query(UserAnswer.user_id).filter_by(
        survey_id=survey_id
    ).group_by(UserAnswer.user_id).all()
    
    user_ids = [ua[0] for ua in user_answers]
    
    if len(user_ids) < 2:
        return False
    
    # Calculate similarity matrix
    similarity_matrix = {}
    for i, user1_id in enumerate(user_ids):
        user1_answers = get_user_answers(user1_id, survey_id)
        for user2_id in user_ids[i+1:]:
            user2_answers = get_user_answers(user2_id, survey_id)
            similarity = calculate_similarity(user1_answers, user2_answers)
            similarity_matrix[(user1_id, user2_id)] = similarity
    
    # Sort pairs by similarity (highest first)
    sorted_pairs = sorted(similarity_matrix.items(), key=lambda x: x[1], reverse=True)
    
    # Form groups greedily
    grouped_users = set()
    group_number = 1
    
    for (user1_id, user2_id), similarity in sorted_pairs:
        if user1_id not in grouped_users and user2_id not in grouped_users:
            # Create a new group
            group = Group(
                survey_id=survey_id,
                name=f"Group {group_number}"
            )
            db.session.add(group)
            db.session.flush()  # Get the group ID
            
            # Add both users to the group
            member1 = GroupMember(group_id=group.id, user_id=user1_id)
            member2 = GroupMember(group_id=group.id, user_id=user2_id)
            db.session.add(member1)
            db.session.add(member2)
            
            grouped_users.add(user1_id)
            grouped_users.add(user2_id)
            group_number += 1
    
    # Handle remaining users (put them in a separate group or with existing groups)
    remaining_users = [uid for uid in user_ids if uid not in grouped_users]
    
    if remaining_users:
        # Try to add remaining users to existing groups (up to 3 members max)
        existing_groups = Group.query.filter_by(survey_id=survey_id).all()
        
        for user_id in remaining_users:
            user_answers = get_user_answers(user_id, survey_id)
            best_group = None
            best_similarity = -1
            
            for group in existing_groups:
                if len(group.members) < 3:
                    # Calculate average similarity with group members
                    group_similarities = []
                    for member in group.members:
                        member_answers = get_user_answers(member.user_id, survey_id)
                        sim = calculate_similarity(user_answers, member_answers)
                        group_similarities.append(sim)
                    
                    avg_similarity = sum(group_similarities) / len(group_similarities)
                    if avg_similarity > best_similarity:
                        best_similarity = avg_similarity
                        best_group = group
            
            if best_group:
                member = GroupMember(group_id=best_group.id, user_id=user_id)
                db.session.add(member)
                grouped_users.add(user_id)
    
    # If there are still remaining users, create new groups for them
    remaining_users = [uid for uid in user_ids if uid not in grouped_users]
    while remaining_users:
        group = Group(
            survey_id=survey_id,
            name=f"Group {group_number}"
        )
        db.session.add(group)
        db.session.flush()
        
        # Add up to 3 users to this group
        for _ in range(min(3, len(remaining_users))):
            user_id = remaining_users.pop(0)
            member = GroupMember(group_id=group.id, user_id=user_id)
            db.session.add(member)
        
        group_number += 1
    
    db.session.commit()
    return True


def get_user_group(user_id, survey_id):
    """Get the group a user belongs to for a specific survey."""
    membership = GroupMember.query.join(Group).filter(
        GroupMember.user_id == user_id,
        Group.survey_id == survey_id
    ).first()
    
    if membership:
        return membership.group
    return None


def add_user_to_group(group_id, user_id):
    """Manually add a user to a group."""
    group = Group.query.get(group_id)
    if not group:
        return False, "Group not found"
    
    if len(group.members) >= 3:
        return False, "Group already has maximum members (3)"
    
    # Check if user is already in a group for this survey
    existing_membership = GroupMember.query.join(Group).filter(
        GroupMember.user_id == user_id,
        Group.survey_id == group.survey_id
    ).first()
    
    if existing_membership:
        return False, "User is already in a group for this survey"
    
    member = GroupMember(group_id=group_id, user_id=user_id)
    db.session.add(member)
    db.session.commit()
    return True, "User added successfully"


def remove_user_from_group(group_id, user_id):
    """Manually remove a user from a group."""
    member = GroupMember.query.filter_by(group_id=group_id, user_id=user_id).first()
    if not member:
        return False, "User not in this group"
    
    db.session.delete(member)
    
    # If group becomes empty, delete it
    group = Group.query.get(group_id)
    if len(group.members) == 0:
        db.session.delete(group)
    
    db.session.commit()
    return True, "User removed successfully"
