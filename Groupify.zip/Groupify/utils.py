"""
Utility functions for survey access code generation and validation
"""
import secrets
import string
from datetime import datetime
from models import Survey

def generate_access_code(prefix="SURVEY", length=6):
    """
    Generate a unique survey access code.
    
    Format: PREFIX-YEAR-RANDOMCODE
    Example: SURVEY-2024-A1B2C3
    
    Args:
        prefix: String prefix for the code (default: SURVEY)
        length: Length of random portion (default: 6)
    
    Returns:
        Unique access code string
    """
    year = datetime.now().year
    
    # Generate random alphanumeric code (uppercase)
    characters = string.ascii_uppercase + string.digits
    random_part = ''.join(secrets.choice(characters) for _ in range(length))
    
    # Format: PREFIX-YEAR-RANDOM
    code = f"{prefix}-{year}-{random_part}"
    
    # Ensure uniqueness - if code exists, generate a new one
    while Survey.query.filter_by(access_code=code).first():
        random_part = ''.join(secrets.choice(characters) for _ in range(length))
        code = f"{prefix}-{year}-{random_part}"
    
    return code


def generate_batch_codes(num_codes, prefix="SURVEY"):
    """
    Generate multiple unique access codes for batch survey creation.
    
    Args:
        num_codes: Number of codes to generate
        prefix: String prefix for all codes
    
    Returns:
        List of unique access codes
    """
    codes = []
    for _ in range(num_codes):
        code = generate_access_code(prefix)
        codes.append(code)
    return codes


def validate_access_code(code):
    """
    Validate if an access code exists and belongs to an active survey.
    
    Args:
        code: Access code to validate
    
    Returns:
        tuple: (is_valid, survey_or_error_message)
    """
    if not code:
        return False, "Access code is required"
    
    # Remove whitespace and convert to uppercase
    code = code.strip().upper()
    
    survey = Survey.query.filter_by(access_code=code).first()
    
    if not survey:
        return False, "Invalid access code"
    
    if survey.status != 'active':
        return False, "This survey is no longer active"
    
    if survey.current_user_count >= survey.max_users_per_survey:
        return False, "This survey has reached maximum capacity"
    
    return True, survey


def format_code_for_display(code):
    """
    Format code for display with proper spacing.
    
    Args:
        code: Access code string
    
    Returns:
        Formatted code string
    """
    if not code:
        return "N/A"
    return code.replace("-", " - ")
