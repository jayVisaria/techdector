from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, IntegerField, SelectField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length, NumberRange
from models import User, Admin

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different one.')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


class AdminLoginForm(FlaskForm):
    username = StringField('Admin Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Admin Login')


class QuestionForm(FlaskForm):
    question_text = TextAreaField('Question', validators=[DataRequired(), Length(max=500)])
    answer_option_1 = StringField('Answer Option 1', validators=[DataRequired(), Length(max=200)])
    answer_option_2 = StringField('Answer Option 2', validators=[DataRequired(), Length(max=200)])
    submit = SubmitField('Save Question')


class SurveyCreationForm(FlaskForm):
    survey_name = StringField('Survey Name', validators=[DataRequired(), Length(max=200)])
    num_surveys = IntegerField('Number of Surveys to Create', validators=[DataRequired(), NumberRange(min=1, max=50)])
    max_users = IntegerField('Max Users per Survey', validators=[DataRequired(), NumberRange(min=2, max=100)])
    survey_type = SelectField('Survey Type', choices=[('public', 'Public - Anyone can join'), ('private', 'Private - Requires access code')], validators=[DataRequired()])
    code_prefix = StringField('Code Prefix (for private surveys)', validators=[Length(max=20)], default='SURVEY')
    submit = SubmitField('Create Surveys')


class GroupAdjustmentForm(FlaskForm):
    group_id = IntegerField('Group ID', validators=[DataRequired()])
    user_id = IntegerField('User ID', validators=[DataRequired()])
    action = SelectField('Action', choices=[('add', 'Add User'), ('remove', 'Remove User')], validators=[DataRequired()])
    submit = SubmitField('Adjust Group')


class JoinWithCodeForm(FlaskForm):
    access_code = StringField('Access Code', validators=[DataRequired(), Length(min=5, max=50)])
    submit = SubmitField('Join Survey')
