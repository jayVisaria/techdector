# Groupify - Survey-Based Group Matching Application

Groupify is a Flask-based web application that helps form groups of similar-minded individuals through intelligent survey matching.

## Features

### Core Functionality
- **User Authentication**: Users can register, log in, and manage their profiles
- **Admin Panel**: Dedicated dashboard for administrators to manage the system
- **Question Management**: Admins can create, edit, and delete survey questions (with exactly 2 answer options)
- **Survey Creation**: Admins can create multiple survey instances with configurable capacity
- **Survey Participation**: Users can join and complete active surveys
- **Intelligent Group Formation**: AI-powered algorithm matches users based on answer similarity
- **Group Management**: Admins can manually adjust groups (2-3 users per group)
- **Group Display**: Users can view their assigned groups and group members

### Design
- **Primary Color**: Deep sky blue (#42A5F5)
- **Background Color**: Light grayish-blue (#ECEFF1)
- **Accent Color**: Vivid orange (#FF7043)
- **Font**: PT Sans (Google Fonts)
- **Layout**: Clean, intuitive, and accessible design
- **Animations**: Subtle transitions for enhanced user experience

## Project Structure

```
matching_app/
├── app.py                      # Main Flask application
├── config.py                   # Configuration settings
├── models.py                   # Database models
├── forms.py                    # WTForms form definitions
├── matching_algorithm.py       # Group matching algorithm
├── requirements.txt            # Python dependencies
├── .env.example               # Example environment variables
├── static/
│   └── css/
│       └── style.css          # Application styles
└── templates/
    ├── base.html              # Base template
    ├── index.html             # Landing page
    ├── login.html             # User login
    ├── register.html          # User registration
    ├── admin_login.html       # Admin login
    ├── user_dashboard.html    # User dashboard
    ├── take_survey.html       # Survey participation
    ├── my_groups.html         # User's groups view
    ├── admin_dashboard.html   # Admin dashboard
    ├── question_form.html     # Question create/edit
    ├── survey_form.html       # Survey creation
    └── admin_groups.html      # Group management
```

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup Steps

1. **Clone or navigate to the project directory**
   ```bash
   cd matching_app
   ```

2. **Create a virtual environment**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On macOS/Linux
   # or
   venv\Scripts\activate  # On Windows
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file and update the following:
   ```
   SECRET_KEY=your-secret-key-here
   DATABASE_URL=sqlite:///groupify.db
   ADMIN_USERNAME=admin
   ADMIN_PASSWORD=admin123
   ```

5. **Initialize the database**
   ```bash
   python app.py
   ```
   
   The database will be created automatically on first run, and an admin account will be created using the credentials from your `.env` file.

## Usage

### Running the Application

```bash
python app.py
```

The application will be available at `http://127.0.0.1:5000`

### Default Admin Credentials

- **Username**: admin (or as set in .env)
- **Password**: admin123 (or as set in .env)

### Workflow

#### For Admins:
1. Log in at `/admin/login`
2. Create questions (each with 2 answer options)
3. Create surveys (specify number of surveys and max users per survey)
4. Monitor survey participation
5. Complete surveys to trigger automatic group formation
6. View and manually adjust groups if needed

#### For Users:
1. Register a new account at `/register`
2. Log in at `/login`
3. Browse available surveys on the dashboard
4. Join and complete surveys
5. View assigned groups at `/my-groups`
6. Connect with group members

### Matching Algorithm

The application uses a similarity-based matching algorithm that:
- Calculates similarity between users based on their survey answers
- Uses cosine similarity and exact match percentage
- Forms groups of 2 users with the highest similarity scores
- Handles remaining users by adding them to compatible groups (max 3 per group)
- Ensures all participants are assigned to a group

## API Endpoints

### Public Routes
- `GET /` - Landing page
- `GET/POST /register` - User registration
- `GET/POST /login` - User login
- `GET /logout` - Logout

### User Routes (Authentication Required)
- `GET /dashboard` - User dashboard
- `GET /survey/<id>/join` - Join a survey
- `POST /survey/<id>/submit` - Submit survey answers
- `GET /my-groups` - View assigned groups

### Admin Routes (Admin Authentication Required)
- `GET/POST /admin/login` - Admin login
- `GET /admin/dashboard` - Admin dashboard
- `GET/POST /admin/questions/new` - Create question
- `GET/POST /admin/questions/<id>/edit` - Edit question
- `POST /admin/questions/<id>/delete` - Delete question
- `GET/POST /admin/surveys/create` - Create surveys
- `POST /admin/surveys/<id>/complete` - Complete survey and form groups
- `GET /admin/surveys/<id>/groups` - View survey groups
- `POST /admin/groups/<group_id>/add_user/<user_id>` - Add user to group
- `POST /admin/groups/<group_id>/remove_user/<user_id>` - Remove user from group

## Database Schema

### Tables
- **users** - User accounts
- **admins** - Administrator accounts
- **questions** - Survey questions
- **surveys** - Survey instances
- **user_answers** - User responses to questions
- **groups** - Formed groups
- **group_members** - Group membership

## Technologies Used

- **Backend**: Flask 3.0.0
- **Database**: SQLAlchemy with SQLite
- **Authentication**: Flask-Login
- **Forms**: Flask-WTF, WTForms
- **Matching Algorithm**: scikit-learn, NumPy
- **Frontend**: HTML5, CSS3
- **Fonts**: PT Sans (Google Fonts)

## Development

### Database Commands

Initialize database:
```bash
flask init-db
```

Create admin account:
```bash
flask create-admin
```

### Testing

To test the application:
1. Start the Flask application
2. Create an admin account
3. Log in as admin and create questions
4. Create surveys
5. Register multiple user accounts
6. Have users complete surveys
7. Complete the survey as admin to form groups
8. View and adjust groups as needed

## Security Notes

- Change the `SECRET_KEY` in production
- Use strong passwords for admin accounts
- Consider using PostgreSQL instead of SQLite for production
- Implement HTTPS in production
- Add rate limiting for API endpoints
- Implement CSRF protection (already included via Flask-WTF)

## Future Enhancements

- Email notifications for group assignments
- Export groups to CSV
- Advanced matching algorithms with weighted questions
- User profile pages
- Group chat functionality
- Survey analytics and reporting
- Multiple admin roles and permissions

## License

This project is for educational purposes.

## Support

For issues or questions, please refer to the documentation or contact the development team.
