#!/bin/bash

echo "🚀 Setting up Groupify..."

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "⚙️  Creating .env file..."
    cp .env.example .env
    echo "✏️  Please edit .env file to set your SECRET_KEY and admin credentials"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "To run the application:"
echo "  1. Activate the virtual environment: source venv/bin/activate"
echo "  2. Start the server: python app.py"
echo "  3. Open your browser to: http://127.0.0.1:5000"
echo ""
echo "Default admin credentials (change in .env):"
echo "  Username: admin"
echo "  Password: admin123"
