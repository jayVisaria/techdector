from flask import Flask, render_template, redirect, url_for, flash, request, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from config import Config
from models import db, User, Admin, Question, Survey, UserAnswer, Group, GroupMember
from forms import (RegistrationForm, LoginForm, AdminLoginForm, QuestionForm, 
                   SurveyCreationForm, GroupAdjustmentForm, JoinWithCodeForm)
from matching_algorithm import form_groups_for_survey, get_user_group, add_user_to_group, remove_user_from_group
from utils import generate_access_code, generate_batch_codes, validate_access_code, format_code_for_display
from functools import wraps

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    # Check if it's an admin session
    if session.get('is_admin'):
        return Admin.query.get(int(user_id))
    return User.query.get(int(user_id))


def admin_required(f):
    """Decorator to require admin authentication."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not session.get('is_admin'):
            flash('You need to be logged in as an admin to access this page.', 'danger')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function


# ============== Public Routes ==============

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated and not session.get('is_admin'):
        return redirect(url_for('dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated and not session.get('is_admin'):
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            session['is_admin'] = False
            flash('Login successful!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.pop('is_admin', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


# ============== User Routes ==============

@app.route('/dashboard')
@login_required
def dashboard():
    if session.get('is_admin'):
        return redirect(url_for('admin_dashboard'))
    
    # Get available PUBLIC surveys only
    available_surveys = Survey.query.filter_by(status='active', survey_type='public').all()
    
    # Get surveys user has participated in
    participated_survey_ids = db.session.query(UserAnswer.survey_id).filter_by(
        user_id=current_user.id
    ).distinct().all()
    participated_survey_ids = [s[0] for s in participated_survey_ids]
    
    # Get user's groups
    user_groups = GroupMember.query.filter_by(user_id=current_user.id).all()
    
    return render_template('user_dashboard.html', 
                         available_surveys=available_surveys,
                         participated_survey_ids=participated_survey_ids,
                         user_groups=user_groups)


@app.route('/survey/<int:survey_id>/join')
@login_required
def join_survey(survey_id):
    if session.get('is_admin'):
        flash('Admins cannot participate in surveys.', 'warning')
        return redirect(url_for('admin_dashboard'))
    
    survey = Survey.query.get_or_404(survey_id)
    
    # Check if survey is active
    if survey.status != 'active':
        flash('This survey is no longer active.', 'warning')
        return redirect(url_for('dashboard'))
    
    # Check if user already participated
    existing_answers = UserAnswer.query.filter_by(
        user_id=current_user.id,
        survey_id=survey_id
    ).first()
    
    if existing_answers:
        flash('You have already completed this survey.', 'info')
        return redirect(url_for('dashboard'))
    
    # Check if survey is full
    if survey.current_user_count >= survey.max_users_per_survey:
        flash('This survey is full.', 'warning')
        return redirect(url_for('dashboard'))
    
    # Get all active questions
    questions = Question.query.filter_by(is_active=True).all()
    
    return render_template('take_survey.html', survey=survey, questions=questions)


@app.route('/survey/<int:survey_id>/submit', methods=['POST'])
@login_required
def submit_survey(survey_id):
    if session.get('is_admin'):
        flash('Admins cannot participate in surveys.', 'warning')
        return redirect(url_for('admin_dashboard'))
    
    survey = Survey.query.get_or_404(survey_id)
    questions = Question.query.filter_by(is_active=True).all()
    
    # Validate all questions are answered
    for question in questions:
        answer_key = f'question_{question.id}'
        if answer_key not in request.form:
            flash('Please answer all questions.', 'danger')
            return redirect(url_for('join_survey', survey_id=survey_id))
    
    # Save answers
    for question in questions:
        answer_choice = int(request.form[f'question_{question.id}'])
        user_answer = UserAnswer(
            user_id=current_user.id,
            survey_id=survey_id,
            question_id=question.id,
            answer_choice=answer_choice
        )
        db.session.add(user_answer)
    
    # Update survey user count
    survey.current_user_count += 1
    db.session.commit()
    
    flash('Survey submitted successfully!', 'success')
    return redirect(url_for('dashboard'))


@app.route('/my-groups')
@login_required
def my_groups():
    if session.get('is_admin'):
        return redirect(url_for('admin_dashboard'))
    
    # Get all groups the user is in
    memberships = GroupMember.query.filter_by(user_id=current_user.id).all()
    
    groups_data = []
    for membership in memberships:
        group = membership.group
        survey = group.survey
        members = []
        for member in group.members:
            members.append(member.user)
        
        groups_data.append({
            'group': group,
            'survey': survey,
            'members': members
        })
    
    return render_template('my_groups.html', groups_data=groups_data)


@app.route('/survey/join-with-code', methods=['GET', 'POST'])
@login_required
def join_with_code():
    if session.get('is_admin'):
        flash('Admins cannot participate in surveys.', 'warning')
        return redirect(url_for('admin_dashboard'))
    
    form = JoinWithCodeForm()
    if form.validate_on_submit():
        is_valid, result = validate_access_code(form.access_code.data.strip().upper())
        
        if not is_valid:
            flash(result, 'danger')
            return render_template('join_with_code.html', form=form)
        
        survey = result
        
        # Check if user already participated
        existing_answers = UserAnswer.query.filter_by(
            user_id=current_user.id,
            survey_id=survey.id
        ).first()
        
        if existing_answers:
            flash('You have already completed this survey.', 'info')
            return redirect(url_for('dashboard'))
        
        # Redirect to survey
        flash(f'Access code accepted! You can now take the survey: {survey.name}', 'success')
        return redirect(url_for('join_survey', survey_id=survey.id))
    
    return render_template('join_with_code.html', form=form)


# ============== Admin Routes ==============

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if current_user.is_authenticated and session.get('is_admin'):
        return redirect(url_for('admin_dashboard'))
    
    form = AdminLoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and admin.check_password(form.password.data):
            login_user(admin)
            session['is_admin'] = True
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid admin credentials', 'danger')
    
    return render_template('admin_login.html', form=form)


@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    questions = Question.query.order_by(Question.created_at.desc()).all()
    surveys = Survey.query.order_by(Survey.created_at.desc()).all()
    
    # Get statistics
    total_users = User.query.count()
    total_questions = Question.query.filter_by(is_active=True).count()
    active_surveys = Survey.query.filter_by(status='active').count()
    
    return render_template('admin_dashboard.html', 
                         questions=questions,
                         surveys=surveys,
                         total_users=total_users,
                         total_questions=total_questions,
                         active_surveys=active_surveys)


@app.route('/admin/questions/new', methods=['GET', 'POST'])
@admin_required
def create_question():
    form = QuestionForm()
    if form.validate_on_submit():
        question = Question(
            question_text=form.question_text.data,
            answer_option_1=form.answer_option_1.data,
            answer_option_2=form.answer_option_2.data
        )
        db.session.add(question)
        db.session.commit()
        flash('Question created successfully!', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('question_form.html', form=form, title='Create Question')


@app.route('/admin/questions/<int:question_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_question(question_id):
    question = Question.query.get_or_404(question_id)
    form = QuestionForm()
    
    if form.validate_on_submit():
        question.question_text = form.question_text.data
        question.answer_option_1 = form.answer_option_1.data
        question.answer_option_2 = form.answer_option_2.data
        db.session.commit()
        flash('Question updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'GET':
        form.question_text.data = question.question_text
        form.answer_option_1.data = question.answer_option_1
        form.answer_option_2.data = question.answer_option_2
    
    return render_template('question_form.html', form=form, title='Edit Question')


@app.route('/admin/questions/<int:question_id>/delete', methods=['POST'])
@admin_required
def delete_question(question_id):
    question = Question.query.get_or_404(question_id)
    question.is_active = False
    db.session.commit()
    flash('Question deleted successfully!', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/surveys/create', methods=['GET', 'POST'])
@admin_required
def create_surveys():
    form = SurveyCreationForm()
    if form.validate_on_submit():
        survey_type = form.survey_type.data
        code_prefix = form.code_prefix.data.strip().upper() if form.code_prefix.data else 'SURVEY'
        
        # Generate access codes for private surveys
        access_codes = []
        if survey_type == 'private':
            access_codes = generate_batch_codes(form.num_surveys.data, code_prefix)
        
        # Create multiple surveys
        for i in range(form.num_surveys.data):
            survey = Survey(
                name=f"{form.survey_name.data} - {i+1}",
                max_users_per_survey=form.max_users.data,
                status='active',
                survey_type=survey_type,
                access_code=access_codes[i] if survey_type == 'private' else None
            )
            db.session.add(survey)
        
        db.session.commit()
        
        if survey_type == 'private':
            flash(f'{form.num_surveys.data} private surveys created successfully! Access codes have been generated.', 'success')
        else:
            flash(f'{form.num_surveys.data} public surveys created successfully!', 'success')
        
        return redirect(url_for('admin_dashboard'))
    
    return render_template('survey_form.html', form=form)


@app.route('/admin/surveys/<int:survey_id>/complete', methods=['POST'])
@admin_required
def complete_survey(survey_id):
    survey = Survey.query.get_or_404(survey_id)
    survey.status = 'completed'
    db.session.commit()
    
    # Form groups automatically
    success = form_groups_for_survey(survey_id)
    
    if success:
        flash('Survey completed and groups formed successfully!', 'success')
    else:
        flash('Survey completed but could not form groups (insufficient participants).', 'warning')
    
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/surveys/<int:survey_id>/groups')
@admin_required
def view_survey_groups(survey_id):
    survey = Survey.query.get_or_404(survey_id)
    groups = Group.query.filter_by(survey_id=survey_id).all()
    
    groups_data = []
    for group in groups:
        members = []
        for member in group.members:
            members.append(member.user)
        groups_data.append({
            'group': group,
            'members': members
        })
    
    # Get all users who participated in this survey
    all_participants = db.session.query(User).join(UserAnswer).filter(
        UserAnswer.survey_id == survey_id
    ).distinct().all()
    
    return render_template('admin_groups.html', 
                         survey=survey, 
                         groups_data=groups_data,
                         all_participants=all_participants)


@app.route('/admin/groups/<int:group_id>/add_user/<int:user_id>', methods=['POST'])
@admin_required
def admin_add_user_to_group(group_id, user_id):
    success, message = add_user_to_group(group_id, user_id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    group = Group.query.get(group_id)
    return redirect(url_for('view_survey_groups', survey_id=group.survey_id))


@app.route('/admin/groups/<int:group_id>/remove_user/<int:user_id>', methods=['POST'])
@admin_required
def admin_remove_user_from_group(group_id, user_id):
    success, message = remove_user_from_group(group_id, user_id)
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    group = Group.query.get(group_id)
    if group:
        return redirect(url_for('view_survey_groups', survey_id=group.survey_id))
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/surveys/<int:survey_id>/regenerate-code', methods=['POST'])
@admin_required
def regenerate_survey_code(survey_id):
    survey = Survey.query.get_or_404(survey_id)
    
    if survey.survey_type != 'private':
        flash('Only private surveys have access codes.', 'warning')
        return redirect(url_for('admin_dashboard'))
    
    # Generate new code
    old_code = survey.access_code
    survey.access_code = generate_access_code()
    db.session.commit()
    
    flash(f'Access code regenerated! Old code: {old_code} → New code: {survey.access_code}', 'success')
    return redirect(url_for('admin_dashboard'))


# ============== Database Initialization ==============

@app.cli.command()
def init_db():
    """Initialize the database."""
    db.create_all()
    print('Database initialized.')


@app.cli.command()
def create_admin():
    """Create an admin account."""
    admin = Admin.query.filter_by(username=app.config['ADMIN_USERNAME']).first()
    if not admin:
        admin = Admin(username=app.config['ADMIN_USERNAME'])
        admin.set_password(app.config['ADMIN_PASSWORD'])
        db.session.add(admin)
        db.session.commit()
        print(f"Admin account created: {app.config['ADMIN_USERNAME']}")
    else:
        print("Admin account already exists.")


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create admin if doesn't exist
        admin = Admin.query.filter_by(username=app.config['ADMIN_USERNAME']).first()
        if not admin:
            admin = Admin(username=app.config['ADMIN_USERNAME'])
            admin.set_password(app.config['ADMIN_PASSWORD'])
            db.session.add(admin)
            db.session.commit()
            print(f"✅ Admin account created: {app.config['ADMIN_USERNAME']}")
        else:
            print(f"✅ Admin account exists: {app.config['ADMIN_USERNAME']}")
    
    print("\n" + "="*60)
    print("🚀 Groupify is starting...")
    print("="*60)
    print("📍 Local URL: http://127.0.0.1:5001")
    print("📍 Admin Login: http://127.0.0.1:5001/admin/login")
    print("="*60 + "\n")
    
    app.run(debug=True, port=5001)
