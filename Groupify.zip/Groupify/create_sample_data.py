"""
Sample data generator for Groupify
Run this script to populate the database with sample questions
"""
from app import app, db
from models import Question

def create_sample_questions():
    """Create sample questions for testing"""
    
    sample_questions = [
        {
            'question_text': 'What is your preferred work style?',
            'answer_option_1': 'I prefer working independently',
            'answer_option_2': 'I prefer working in teams'
        },
        {
            'question_text': 'How do you approach problem-solving?',
            'answer_option_1': 'I analyze data and think logically',
            'answer_option_2': 'I brainstorm creative solutions'
        },
        {
            'question_text': 'What time of day are you most productive?',
            'answer_option_1': 'Morning person - I work best early',
            'answer_option_2': 'Night owl - I work best late'
        },
        {
            'question_text': 'How do you prefer to communicate?',
            'answer_option_1': 'Written communication (email, chat)',
            'answer_option_2': 'Verbal communication (calls, meetings)'
        },
        {
            'question_text': 'What motivates you the most?',
            'answer_option_1': 'Achieving personal goals',
            'answer_option_2': 'Contributing to team success'
        },
        {
            'question_text': 'How do you handle deadlines?',
            'answer_option_1': 'I work steadily and finish early',
            'answer_option_2': 'I work best under pressure'
        },
        {
            'question_text': 'What learning style do you prefer?',
            'answer_option_1': 'Hands-on practical experience',
            'answer_option_2': 'Reading and theoretical study'
        },
        {
            'question_text': 'How do you make decisions?',
            'answer_option_1': 'Based on facts and logic',
            'answer_option_2': 'Based on intuition and feelings'
        },
        {
            'question_text': 'What is your approach to planning?',
            'answer_option_1': 'Detailed planning and organization',
            'answer_option_2': 'Flexible and spontaneous'
        },
        {
            'question_text': 'How do you handle feedback?',
            'answer_option_1': 'I prefer direct, constructive criticism',
            'answer_option_2': 'I prefer gentle, encouraging feedback'
        }
    ]
    
    with app.app_context():
        # Check if questions already exist
        existing_count = Question.query.count()
        if existing_count > 0:
            print(f"Database already has {existing_count} questions.")
            response = input("Do you want to add more sample questions? (y/n): ")
            if response.lower() != 'y':
                print("Skipping question creation.")
                return
        
        # Create questions
        print("Creating sample questions...")
        for q_data in sample_questions:
            question = Question(
                question_text=q_data['question_text'],
                answer_option_1=q_data['answer_option_1'],
                answer_option_2=q_data['answer_option_2'],
                is_active=True
            )
            db.session.add(question)
        
        db.session.commit()
        print(f"✅ Successfully created {len(sample_questions)} sample questions!")
        print("\nYou can now:")
        print("1. Log in as admin")
        print("2. Create surveys")
        print("3. Have users take surveys")
        print("4. Form groups based on similarity")

if __name__ == '__main__':
    create_sample_questions()
